const QueryType = require('./Query');

module.exports = QueryType;